const express = require('express');
const db = require('../config/db');

const { createRequest, getRequestsByCategory } = require('../models/customerRequest');
const router = express.Router();

router.post('/submit', (req, res) => {
    const { userId, category, comments } = req.body;
    createRequest(userId, category, comments, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(201).json({ message: 'Request submitted successfully' });
        }
    });
});

router.get('/requests', (req, res) => {
    let { category } = req.query; // Correctly destructure category from req.query
    if(category){
        const queryii = 'SELECT * FROM customer_requests WHERE category = ?';
        db.query(queryii, [category], (err, results) => { // Handle the database query with a callback
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.status(200).json(results);
            }
        });
    }
    else{
        const queryii = 'SELECT * FROM customer_requests';
        db.query(queryii, (err, results) => { // Handle the database query with a callback
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.status(200).json(results);
            }
        });

    }

});




module.exports = router;
