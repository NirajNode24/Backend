const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const passport = require('passport');
const dotenv = require('dotenv');
const cors = require('cors');







dotenv.config();
require('./config/db');
require('./config/passport');

const authRoutes = require('./routes/auth');
const customerServiceRoutes = require('./routes/customerService');

const app = express();
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(session({ secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false }));

app.use(passport.initialize());
app.use(passport.session());

app.use('/auth', authRoutes);
app.use('/customer-service', customerServiceRoutes);

app.get('/', (req, res) => {
    res.send('Welcome to the Customer Service Backend');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
