const db = require('../config/db');

const createRequest = (userId, category, comments, callback) => {
    const query = 'INSERT INTO customer_requests (user_id, category, comments) VALUES (?, ?, ?)';
    db.query(query, [userId, category, comments], callback);
};

const getRequestsByCategory = (category, callback) => {
    console.log(category)
};

module.exports = {
    createRequest,
    getRequestsByCategory
};
